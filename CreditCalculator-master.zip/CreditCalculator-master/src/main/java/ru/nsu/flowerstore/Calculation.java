package ru.nsu.flowerstore;

import java.util.Calendar;

public class Calculation {
    private int sumOfCredit;
    private double interestRate;
    private int numberOfMonth;

    public Calculation(int sumOfCredit, double interestRate, int numberOfMonth) {
        this.sumOfCredit = sumOfCredit;
        this.interestRate = interestRate;
        this.numberOfMonth = numberOfMonth;
    }

    public double sumCalculate(){
        return sumOfCredit*(1+totalInterestRate()/100);
    }

    public double totalInterestRate(){
        return interestRate*numberOfMonth/12;
    }

    public double getMonthPaymentSum(){
        return sumCalculate()/numberOfMonth;
    }

    public double getMonthInterestRate(){
        return interestRate/12;
    }
    public String getDate(int numberMonth){
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, + numberMonth);
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH)+1;
        final int day = calendar.get(Calendar.DAY_OF_MONTH);
        String s = day+"-"+month+"-"+year;
        return s;
    }

}
