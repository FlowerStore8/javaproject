package ru.nsu.flowerstore;

import java.sql.*;

public class Main {
    public void main() throws ClassNotFoundException, SQLException {

    }
}
