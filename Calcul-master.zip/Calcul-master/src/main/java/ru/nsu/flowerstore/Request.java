package ru.nsu.flowerstore;

import org.joda.time.LocalDate;
import org.joda.time.Years;

public class Request {

    String name;
    String secondName;
    String lastName;
    String gender;
    String phone;
    int age;
    int sum;
    int time;

    public Request(String name, String secondName, String lastName,
                   String birthday, String gender, String phone, int sum, int time){
        this.name = name;
        this.secondName = secondName;
        this.lastName = lastName;
        String[] birth = birthday.split("-");
        int year = Integer.parseInt(birth[2]);
        int month = Integer.parseInt(birth[1]);
        int day = Integer.parseInt(birth[0]);
        this.age = Years.yearsBetween(new LocalDate(day, month, year), new LocalDate()).getYears();
        this.gender = gender;
        this.phone = phone;
        this.sum = sum;
        this.time = time;
    }


    public String getName() {
        return name;
    }

    public String getSecondName() {
        return secondName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getGender() {
        return gender;
    }

    public String getPhone() {
        return phone;
    }

    public int getAge() {
        return age;
    }

    public int getSum() {
        return sum;
    }

    public int getTime() {
        return time;
    }

    public Request(String name, String secondName, String lastName, int age, String gender,
                   String phone, int sum, int time) {
        this.name = name;
        this.secondName = secondName;
        this.lastName = lastName;
        this.age = age;
        this.gender = gender;
        this.phone = phone;
        this.sum = sum;
        this.time = time;
    }

    public String toSql(){
        return "('"+name+"', "+
                "'"+secondName+"', "+
                "'"+lastName+"', "+
                +age+", "+
                "'"+phone+"', "+
                +sum+", "+
                +time+", "+
                "'"+gender+"')";
    }

}
