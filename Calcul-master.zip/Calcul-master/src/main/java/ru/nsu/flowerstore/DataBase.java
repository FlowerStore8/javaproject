package ru.nsu.flowerstore;

import java.sql.SQLException;
import java.util.ArrayList;

public interface DataBase {
    public Data getData() throws SQLException, ClassNotFoundException;
    public void changeData(Data date) throws SQLException, ClassNotFoundException, ValidateException;
    public void request(Request req);
    public ArrayList<Request> getRequests();
}
