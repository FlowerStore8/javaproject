package Servlets;

import org.decimal4j.util.DoubleRounder;
import ru.nsu.flowerstore.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/request")
public class CreditRequestServlet extends HttpServlet{

    int sumThis;
    int timeThis;

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            Object sum = req.getParameter("sum");
            Object time = req.getParameter("time");
            sumThis = Integer.parseInt(sum.toString());
            timeThis = Integer.parseInt(time.toString());
            getServletContext().getRequestDispatcher("/request/CreditRequest.jsp").forward(req, resp);
        } catch (Exception ex){
            PrintWriter writer = resp.getWriter();
            writer.println("<h1> Oops, something went wrong </h1>");
            ex.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        try {
            DataBase dataBase = new DataBaseImpl();
            String name = req.getParameter("name");
            String secondName = req.getParameter("secondName");
            String lastName = req.getParameter("lastName");
            String birthday = req.getParameter("birthday");
            String gender = req.getParameter("gender");
            String phone = req.getParameter("phone");
            Request newReq = new Request(name, secondName, lastName, birthday,
                    gender, phone, sumThis, timeThis);
            dataBase.request(newReq);
            getServletContext().getRequestDispatcher("/request/RequestAccepted.jsp").forward(req, resp);
        } catch (Exception ex){
            PrintWriter writer = resp.getWriter();
            writer.println("<h1> Oops, something went wrong </h1>");
            ex.printStackTrace();
        }
    }
}
