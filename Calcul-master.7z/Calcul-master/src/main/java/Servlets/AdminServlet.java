
package Servlets;

import ru.nsu.flowerstore.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/settings")
public class AdminServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        DataBase dataBase = new DataBaseImpl();
        ArrayList<Request> requests = dataBase.getRequests();
        System.out.println(requests);
        req.setAttribute("requests", requests);
        getServletContext().getRequestDispatcher("/admin/Admin.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String minSum = req.getParameter("minSum");
        String maxSum = req.getParameter("maxSum");
        String minMonth = req.getParameter("minMonth");
        String maxMonth = req.getParameter("maxMonth");
        String intRate = req.getParameter("intRate");
        Data data = new Data(minSum, maxSum, minMonth, maxMonth, intRate);
        try {
            DataBaseImpl database = new DataBaseImpl();
            database.changeData(data);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } catch (ValidateException ex) {
            req.setAttribute("data", data);
            getServletContext().getRequestDispatcher("/admin/AdminException.jsp").forward(req, resp);
        } finally {
            getServletContext().getRequestDispatcher("/admin/AdminValidated.jsp").forward(req, resp);
        }
    }

}