package ru.nsu.flowerstore;

public class ValidateException extends Exception{
    public ValidateException(){
        super("Ошибка валидации данных");
    }
}