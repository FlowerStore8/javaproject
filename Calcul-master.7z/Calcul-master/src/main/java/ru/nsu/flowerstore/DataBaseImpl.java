package ru.nsu.flowerstore;

import java.sql.*;
import java.util.ArrayList;

public class DataBaseImpl implements DataBase {

    public Data getData() throws SQLException, ClassNotFoundException {
        Data data = null;
        try{
        Class.forName("com.mysql.jdbc.Driver");
        String url = "jdbc:mysql://remotemysql.com:3306/nbd7TAXbxf?useSSL=false";
        String user = "nbd7TAXbxf";
        String password = "9SSWe2taFx";
            try (Connection con = DriverManager.getConnection(url, user, password)) {
                Statement stmt = con.createStatement();
                String query = "SELECT * FROM `Admin` WHERE id=(SELECT MAX(id) FROM `Admin`)";
                ResultSet resultSet = stmt.executeQuery(query);
                resultSet.next();
                String minSum = String.valueOf(resultSet.getInt(2));
                String maxSum = String.valueOf(resultSet.getInt(3));
                String minTime = String.valueOf(resultSet.getInt(4));
                String maxTime = String.valueOf(resultSet.getInt(5));
                String rate = String.valueOf(resultSet.getDouble(6));
                data = new Data(minSum, maxSum, minTime, maxTime, rate);
                stmt.close();
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }


    public void changeData(Data data) throws SQLException, ClassNotFoundException, ValidateException {
        if(data.getErrorMessages().size() == 0) {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                String url = "jdbc:mysql://remotemysql.com:3306/nbd7TAXbxf?useSSL=false";
                String user = "nbd7TAXbxf";
                String password = "9SSWe2taFx";
                try (Connection con = DriverManager.getConnection(url, user, password)) {
                    Statement stmt = con.createStatement();
                    String update = "INSERT INTO `Admin` (`minSum`, `maxSum`, `minTime`, " +
                            "`maxTime`, `rate`) " +
                            "VALUES " + data.toSql();
                    stmt.execute(update);
                    stmt.close();
                }
            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            throw new ValidateException();
        }
    }

    public void request(Request req){

        try{
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://remotemysql.com:3306/nbd7TAXbxf?useSSL=false";
            String user = "nbd7TAXbxf";
            String password = "9SSWe2taFx";
            try (Connection con = DriverManager.getConnection(url, user, password)) {
                Statement stmt = con.createStatement();
                String update = "INSERT INTO `Requests` (`name`, `secondName`, `lastName`, " +
                        "`age`, `phone`, `sum`, `time`, `gender`) " +
                        "VALUES " + req.toSql();
                stmt.execute(update);
                stmt.close();
            }
        }catch (ClassNotFoundException | SQLException e){
            e.printStackTrace();
        }
    }

    public ArrayList<Request> getRequests() {
        ArrayList<Request> requests = new ArrayList<>();
        try{
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://remotemysql.com:3306/nbd7TAXbxf?useSSL=false";
            String user = "nbd7TAXbxf";
            String password = "9SSWe2taFx";
            try (Connection con = DriverManager.getConnection(url, user, password)) {
                Statement stmt = con.createStatement();
                String query = "SELECT * FROM `Requests`";
                ResultSet resultSet = stmt.executeQuery(query);
                while(resultSet.next()) {
                    String lastName = resultSet.getString(2);
                    String name = resultSet.getString(3);
                    String secondName = resultSet.getString(4);
                    String gender = resultSet.getString(5);
                    int age = resultSet.getInt(6);
                    String phone = resultSet.getString(7);
                    int sum = resultSet.getInt(8);
                    int time = resultSet.getInt(9);
                    Request request = new Request(name, secondName, lastName, age, gender, phone, sum, time);
                    requests.add(request);
                }
                stmt.close();
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        return requests;
    }


}